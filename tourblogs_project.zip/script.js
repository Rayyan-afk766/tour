
document.getElementById('modeToggle').addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
});

const placesInfo = {
  paris: {
    title: "Paris, France 🇫🇷",
    description: "• Famous Foods: Croissants, Macarons, Baguettes<br>• Places: Eiffel Tower, Louvre Museum<br>• Ancient Sculptures: Venus de Milo at the Louvre",
    image: "images/paris.jpg"
  },
  kyoto: {
    title: "Kyoto, Japan 🇯🇵",
    description: "• Famous Foods: Kaiseki Ryori, Matcha Desserts<br>• Places: Fushimi Inari Shrine, Bamboo Forest<br>• Ancient Sculptures: Buddha statues in ancient temples",
    image: "images/kyoto.jpg"
  },
  cairo: {
    title: "Cairo, Egypt 🇪🇬",
    description: "• Famous Foods: Koshari, Falafel<br>• Places: Pyramids of Giza, Egyptian Museum<br>• Ancient Sculptures: Great Sphinx of Giza",
    image: "images/cairo.jpg"
  },
  newyork: {
    title: "New York, USA 🇺🇸",
    description: "• Famous Foods: Bagels, Cheesecake<br>• Places: Statue of Liberty, Times Square<br>• Modern Sculptures: Charging Bull on Wall Street",
    image: "images/newyork.jpg"
  },
  rome: {
    title: "Rome, Italy 🇮🇹",
    description: "• Famous Foods: Pasta Carbonara, Gelato<br>• Places: Colosseum, Vatican City<br>• Ancient Sculptures: Roman Forum ruins",
    image: "images/rome.jpg"
  },
  bali: {
    title: "Bali, Indonesia 🇮🇩",
    description: "• Famous Foods: Nasi Goreng, Satay<br>• Places: Uluwatu Temple, Tegallalang Rice Terraces<br>• Ancient Sculptures: Traditional Balinese stone carvings",
    image: "images/bali.jpg"
  },
  santorini: {
    title: "Santorini, Greece 🇬🇷",
    description: "• Famous Foods: Moussaka, Fresh Seafood<br>• Places: Oia Village, Red Beach<br>• Ancient Sculptures: Akrotiri ruins",
    image: "images/santorini.jpg"
  }
};

function openPopup(place) {
  const popup = document.getElementById('popup');
  const popupInfo = document.getElementById('popupInfo');
  const data = placesInfo[place];

  popupInfo.innerHTML = `
    <h2>${data.title}</h2>
    <img src="${data.image}" alt="${data.title}" style="width: 100%; border-radius: 15px; margin-top: 10px;">
    <p style="margin-top: 15px;">${data.description}</p>
  `;
  popup.classList.add('show');
}

function closePopup() {
  document.getElementById('popup').classList.remove('show');
}
